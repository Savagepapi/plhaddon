
local function GetCurrentProfession()
  for i = 1, GetNumSkillLines() do
    local name, isHeader, _, skillRank = GetSkillLineInfo(i)
    if not isHeader and ProfessionGuides[name] then
      return name, skillRank
    end
  end
  return nil, 0
end

local function ShowGuide()
  local prof, level = GetCurrentProfession()
  if not prof then
    print("|cffff0000[PLH]|r No supported profession found!")
    return
  end

  print("|cff00ff00[PLH]|r Profession: " .. prof .. " (Skill: " .. level .. ")")
  print("|cff9999ffNext recommended steps:")

  local guide = ProfessionGuides[prof]
  local shown = 0

  for _, step in ipairs(guide) do
    if level < step.level and shown < 3 then
      print(string.format(" %s %s @ %d → %s", step.color or "🔹", step.recipe, step.level, step.mats or ""))
      shown = shown + 1
    end
  end

  if shown == 0 then
    print("|cffffff00You're maxed out or no further steps in this guide.")
  end
end

SLASH_PLH1 = "/plh"
SlashCmdList["PLH"] = ShowGuide

function AddItemCountsToText(rawText)
  local updatedText = ""
  local lastColorCode = ""
  local firstLine = true

  for line in rawText:gmatch("([^\r\n]*)\r?\n?") do
      local newLine = line

      -- Színkód keresése az aktuális sorban
      local currentColor = line:match("^(|c%x%x%x%x%x%x%x%x)")
      if currentColor then
          lastColorCode = currentColor
      end

      -- Ha ez addon név sor (pl. csak színkód van benne, nincs benne "x")
      local isAddonHeader = currentColor and not line:find("%d+x")

      -- Ha addon név, előtte is rakjunk sortörést (kivéve ha az első sor)
      if isAddonHeader and not firstLine then
          updatedText = updatedText .. "\n"
      end

      -- Itt a továbbfejlesztett pattern:
      for count, itemName in line:gmatch("(%d+)x ([^,\(\-\n]+)") do
          local trimmedName = itemName:gsub("^%s*(.-)%s*$", "%1")
          local bagCount = GetItemCount(trimmedName, false)
          local countText = lastColorCode .. "[" .. bagCount .. "]|r"
          -- csak egyszer cseréljük (ha egy sorban többször lenne ugyanez, ne legyen többszörös beszúrás)
          newLine = newLine:gsub(count .. "x " .. trimmedName, count .. "x " .. trimmedName .. " " .. countText, 1)
      end

      updatedText = updatedText .. newLine .. "\n"

      -- Ha addon fejléc volt, akkor utána is rakunk sortörést
      if isAddonHeader then
          updatedText = updatedText .. "\n"
      end

      firstLine = false
  end

  return updatedText
end