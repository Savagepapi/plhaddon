
ProfessionGuides = {
        
    ["Engineering"] = {
        
    -- Classic

    { level = 1,   recipe = "1-30 20x Rough Blasting Powder",        color = "|cffffff00", mats = "20x Rough Stone" },
    { level = 30,  recipe = "30-50 20x Handful of Copper Bolts",     color = "|cffffff00", mats = "20x Copper Bar" },
    { level = 50,  recipe = "50-80 10x Copper Tube",                 color = "|cffffff00", mats = "20x Copper Bar, 10x Weak Flux" },
    { level = 80,  recipe = "80-97 20x Coarse Blasting Powder",      color = "|cffffff00", mats = "20x Coarse Stone" },
    { level = 97,  recipe = "97-100 1x Silver Contact",              color = "|cffffff00", mats = "1x Silver Bar" },
    { level = 100, recipe = "100-120 10x Practice Lock",             color = "|cffffff00", mats = "10x Bronze Bar, 20x Handful of Copper Bolts, 10x Weak Flux" },
    { level = 120, recipe = "120-125 5x Bronze Tube",                color = "|cffffff00", mats = "10x Bronze Bar" },
    { level = 125, recipe = "125-140 20x Heavy Blasting Powder",     color = "|cffffff00", mats = "20x Heavy Stone" },
    { level = 140, recipe = "140-150 5x Big Bronze Bomb",            color = "|cffffff00", mats = "15x Bronze Bar, 10x Heavy Blasting Powder, 5x Silver Contact" },
    { level = 150, recipe = "150-160 5x Aquadynamic Fish Attractor", color = "|cffffff00", mats = "10x Bronze Bar, 5x Coarse Blasting Powder, 5x Nightcrawlers" },
    { level = 160, recipe = "160-172 5x Gold Power Core",            color = "|cffffff00", mats = "5x Gold Bar" },
    { level = 172, recipe = "172-175 1x Gyrochronaton",              color = "|cffffff00", mats = "5x Iron Bar, 5x Gold Power Core" },
    { level = 175, recipe = "175-196 30x Solid Blasting Powder",     color = "|cffffff00", mats = "60x Solid Stone" },
    { level = 196, recipe = "196-200 7x Mithril Tube",               color = "|cffffff00", mats = "21x Mithril Bar" },
    { level = 200, recipe = "200-210 5x Unstable Trigger",           color = "|cffffff00", mats = "5x Mithril Bar, 5x Solid Blasting Powder, 5x Mageweave Cloth" },
    { level = 210, recipe = "210-232 10x Hi-Impact Mithril Slugs",   color = "|cffffff00", mats = "10x Mithril Bar" },
    { level = 232, recipe = "232-235 10x Mithril Casing",            color = "|cffffff00", mats = "30x Mithril Bar" },
    { level = 235, recipe = "235-250 5x Hi-Explosive Bomb",          color = "|cffffff00", mats = "10x Mithril Casing, 5x Unstable Trigger, 10x Solid Blasting Powder" },
    { level = 250, recipe = "250-260 20x Dense Blasting Powder",     color = "|cffffff00", mats = "40x Dense Stone" },
    { level = 260, recipe = "260-270 3x Thorium Widget",             color = "|cffffff00", mats = "9x Thorium Bar, 3x Runecloth" },
    { level = 270, recipe = "270-275 2x Thorium Grenade",            color = "|cffffff00", mats = "2x Thorium Widget, 6x Thorium Bar, 6x Runecloth, 6x Dense Blasting Powder" },
    { level = 275, recipe = "275-285 5x Thorium Widget",             color = "|cffffff00", mats = "15x Thorium Bar, 5x Runecloth" },
    { level = 285, recipe = "285-300 5x Thorium Shells",             color = "|cffffff00", mats = "10x Thorium Bar, 5x Dense Blasting Powder" },

    -- TBC

    { level = 300, recipe = "300-315 12x Handful of Fel Iron Bolts", color = "|cff00ff00", mats = "12x Fel Iron Bar" },
    { level = 300, recipe = "300-315 2x Fel Iron Casing",            color = "|cff00ff00", mats = "6x Fel Iron Bar" },
    { level = 300, recipe = "300-315 10x Elemental Blasting Powder", color = "|cff00ff00", mats = "10x Mote of Fire, 20x Mote of Earth" },
    { level = 315, recipe = "315-320 5x Fel Iron Shells",            color = "|cff00ff00", mats = "10x Fel Iron Bar, 5x Elemental Blasting Powder" },
    { level = 320, recipe = "320-325 2x Fel Iron Bomb",              color = "|cff00ff00", mats = "2x Elemental Blasting Powder, 4x Handful of Fel Iron Bolts, 2x Fel Iron Casing" },
    { level = 325, recipe = "325-335 4x Adamantite Grenade",         color = "|cff00ff00", mats = "16x Adamantite Bar, 4x Elemental Blasting Powder, 8x Handful of Fel Iron Bolts" },
    { level = 335, recipe = "335-350 20x White Smoke Flare",         color = "|cff00ff00", mats = "20x Netherweave Cloth, 20x Elemental Blasting Powder" },

    -- WotLK

    { level = 350, recipe = "350-370 10x Handful of Cobalt Bolts",   color = "|cff00ffff", mats = "20x Cobalt Bar" },
    { level = 370, recipe = "370-375 8x Volatile Blasting Trigger",  color = "|cff00ffff", mats = "24x Cobalt Bar, 8x Crystallized Water" },
    { level = 375, recipe = "375-390 5x Explosive Decoy",            color = "|cff00ffff", mats = "5x Frostweave Cloth, 15x Volatile Blasting Trigger" },
    { level = 390, recipe = "390-408 3x Froststeel Tube",            color = "|cff00ffff", mats = "24x Cobalt Bar, 3x Crystallized Water" },
    { level = 393, recipe = "390-408 3x Diamond-cut Refractor Scope", color = "|cff00ffff", mats = "6x Handful of Cobalt Bolts, 3x Froststeel Tube" },
        { level = 408, recipe = "408-411 2x Box of Bombs",                   color = "|cff00ffff", mats = "10x Saronite Bar, 2x Volatile Blasting Trigger" },
        { level = 411, recipe = "411-417 5x Mammoth Cutters",                color = "|cff00ffff", mats = "5x Saronite Bar, 5x Volatile Blasting Trigger" },
        { level = 417, recipe = "417-426 3x Mana Injector Kit",              color = "|cff00ffff", mats = "36x Saronite Bar, 6x Crystallized Water" },
        { level = 426, recipe = "426-432 2x MOLL-E",                         color = "|cff00ffff", mats = "16x Saronite Bar, 16x Eternal Air" },
        { level = 432, recipe = "432-438 2x Heartseeker Scope",              color = "|cff00ffff", mats = "20x Saronite Bar, 4x Twilight Opal\n" },
        { level = 438, recipe = "438-447 3x Gnomish Army Knife",             color = "|cff00ffff", mats = "30x Saronite Bar, 3x Skinning Knife, 3x Mining Pick, 3x Blacksmith Hammer\n\n" },
        { level = 447, recipe = "447-450 1x Wormhole Generator: Northrend", color = "|cff00ffff", mats = "8x Titanium Bar, 2x Eternal Shadow, 2x Eternal Water, 2x Eternal Fire, 2x Eternal Air" },

    },    
}

-- 🔧 Létrehoz egy sort a guide listába Craft gombbal
local function CreateGuideRow(parent, yOffset, recipeText, matsText)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(300, 40)
    row:SetPoint("TOPLEFT", 0, -yOffset)

    -- 🧹 Tisztítjuk a színkódokat, hogy a keresés pontos legyen
    local recipeClean = recipeText:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    local recipeName = recipeClean:match("%d+x%s(.+)") or recipeClean

    local text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    text:SetPoint("LEFT")
    text:SetWidth(230)
    text:SetJustifyH("LEFT")
    text:SetText(recipeText .. "\n|cffaaaaaa" .. matsText .. "|r")

    local craftButton = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    craftButton:SetSize(50, 20)
    craftButton:SetPoint("RIGHT")
    craftButton:SetText("Craft")

    craftButton:SetScript("OnClick", function()
        for i = 1, GetNumTradeSkills() do
            local name, type = GetTradeSkillInfo(i)
            if name == recipeName and type ~= "header" then
                DoTradeSkill(i, 1)
                print("|cff00ff00Crafting started:|r " .. name)
                return
            end
        end
        print("|cffff0000Recipe not found:|r " .. recipeName)
    end)

    return row
end

-----------------------------------------------------------------------------
SLASH_PLHENGINEERING1 = "/plheng"
SlashCmdList["PLHENGINEERING"] = function()
    -- Ha már meg van nyitva, zárja be
    if PLHEngineeringFrame and PLHEngineeringFrame:IsShown() then
        PLHEngineeringFrame:Hide()
        return
    end

    -- Ha még nincs létrehozva, hozzuk létre
    if not PLHEngineeringFrame then
        local frame = CreateFrame("Frame", "PLHEngineeringFrame", UIParent, "BackdropTemplate")
        frame:SetSize(575, 445)
        frame:SetPoint("CENTER")
        frame:SetBackdrop({
            bgFile = "Interface/DialogFrame/UI-DialogBox-Background",
            edgeFile = "Interface/DialogFrame/UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 8, right = 8, top = 8, bottom = 8 }
        })
        frame:SetMovable(true)
        frame:EnableMouse(true)
        frame:RegisterForDrag("LeftButton")
        frame:SetScript("OnDragStart", frame.StartMoving)
        frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
        frame:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
            end
        end)

        -- Fejléc
        local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        title:SetPoint("TOP", 0, -10)
        title:SetText("Engineering Guide")
        title:SetFont("Fonts\\FRIZQT__.TTF", 16)

        -- Bezáró gomb
        local closeButton = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
        closeButton:SetPoint("TOPRIGHT", -5, -5)
        closeButton:SetScript("OnClick", function()
            frame:Hide()
        end)

        -- Frissítés gomb
        local refreshButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
        refreshButton:SetSize(60, 20)
        refreshButton:SetPoint("RIGHT", closeButton, "LEFT", -4, 0)
        refreshButton:SetText("Refresh")
refreshButton:SetScript("OnClick", function()
    if PLHEngineeringFrame then
        local frame = PLHEngineeringFrame

        -- 🔹 Tartalom törlése az első scroll frame-ből
        local content = frame.scrollFrame1:GetScrollChild()
        for _, child in ipairs({ content:GetChildren() }) do
            child:Hide()
            child:SetParent(nil)
        end

        -- 🔹 Újrabetöltés
        local guideLines = ProfessionGuides and ProfessionGuides["Engineering"]
        if guideLines and #guideLines > 0 then
            local y = 0
            for _, guide in ipairs(guideLines) do
                local row = CreateGuideRow(content, y, (guide.color or "") .. guide.recipe .. "|r", guide.mats)
                y = y + 45
            end
            content:SetHeight(y)
            frame.scrollFrame1:UpdateScrollChildRect()
        else
            print("|cffff0000Guide not found.|r")
        end

        -- 🔹 Második oszlop frissítése
        local text2 = AddItemCountsToText([[|cffFFFF00Classic|r

20x Rough Stone
40x Copper Bar
20x Weak Flux
20x Coarse Stone
1x Silver Bar
45x Bronze Bar
20x Heavy Stone
4x Silver Contact
5x Nightcrawlers
5x Gold Bar
5x Iron Bar
60x Solid Stone
66x Mithril Bar
5x Mageweave Cloth
40x Dense Stone
40x Thorium Bar
14x Runecloth

|cff00ff00TBC|r

28x Fel Iron Bar
10x Mote of Fire
20x Mote of Earth
21x Elemental Blasting Powder
16x Adamantite Bar
20x Netherweave Cloth

|cff00ffffWotLK|r

68x Cobalt Bar
17x Crystallized Water
5x Frostweave Cloth
6x Volatile Blasting Trigger
117x Saronite Bar
18x Eternal Air
4x Twilight Opal
3x Skinning Knife
3x Mining Pick
3x Blacksmith Hammer
8x Titanium Bar
2x Eternal Shadow
2x Eternal Water
2x Eternal Fire
]])

        frame.fontString2:SetText(text2)
        frame.scrollFrame2:UpdateScrollChildRect()
        local h2 = frame.fontString2:GetStringHeight()
        frame.fontString2:GetParent():SetSize(200, h2 > 400 and h2 or 400)
    end
end)

        -- Első scroll frame
        local scrollFrame1 = CreateFrame("ScrollFrame", "PLHScrollFrame1", frame, "UIPanelScrollFrameTemplate")
        scrollFrame1:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -32)
        scrollFrame1:SetSize(300, 400)
        frame.scrollFrame1 = scrollFrame1

        local content1 = CreateFrame("Frame", nil, scrollFrame1)
        scrollFrame1:SetScrollChild(content1)

        local fontString1 = content1:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
        fontString1:SetPoint("TOPLEFT")
        fontString1:SetWidth(300)
        fontString1:SetWordWrap(true)
        fontString1:SetJustifyH("LEFT")
        fontString1:SetJustifyV("TOP")
        fontString1:SetFont("Fonts\\FRIZQT__.TTF", 14)

        local textHeight1 = fontString1:GetStringHeight()
        content1:SetSize(300, textHeight1 > 400 and textHeight1 or 400)

        -- Második scroll frame
        local scrollFrame2 = CreateFrame("ScrollFrame", "PLHScrollFrame2", frame, "UIPanelScrollFrameTemplate")
        scrollFrame2:SetPoint("TOPLEFT", scrollFrame1, "TOPRIGHT", 24, 0)
        scrollFrame2:SetSize(200, 400)
        frame.scrollFrame2 = scrollFrame2

        local content2 = CreateFrame("Frame", nil, scrollFrame2)
        scrollFrame2:SetScrollChild(content2)

        local fontString2 = content2:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
        fontString2:SetPoint("TOPLEFT")
        fontString2:SetWidth(200)
        fontString2:SetWordWrap(true)
        fontString2:SetJustifyH("LEFT")
        fontString2:SetJustifyV("TOP")
        fontString2:SetText("Additional content loading...")
        fontString2:SetFont("Fonts\\FRIZQT__.TTF", 14)

        local textHeight2 = fontString2:GetStringHeight()
        content2:SetSize(200, textHeight2 > 400 and textHeight2 or 400)

        frame.fontString1 = fontString1
        frame.fontString2 = fontString2
        PLHEngineeringFrame = frame
    end

    -- 🔍 Betöltjük a guide-t és a második scroll frame tartalmát
    local guideLines = ProfessionGuides and ProfessionGuides["Engineering"]
    if guideLines and #guideLines > 0 then
        -- 🔄 Sorok létrehozása Craft gombbal
local content = PLHEngineeringFrame.scrollFrame1:GetScrollChild()
for _, child in ipairs({content:GetChildren()}) do
    child:Hide()
end

local y = 0
for _, guide in ipairs(guideLines) do
    local row = CreateGuideRow(content, y, (guide.color or "") .. guide.recipe .. "|r", guide.mats)
    y = y + 45
end
content:SetHeight(y)

        PLHEngineeringFrame.scrollFrame1:UpdateScrollChildRect()
        local h1 = PLHEngineeringFrame.fontString1:GetStringHeight()
        PLHEngineeringFrame.fontString1:GetParent():SetSize(300, h1 > 400 and h1 or 400)

        local text2 = AddItemCountsToText([[|cffFFFF00Classic|r

20x Rough Stone
40x Copper Bar
20x Weak Flux
20x Coarse Stone
1x Silver Bar
45x Bronze Bar
20x Heavy Stone
4x Silver Contact
5x Nightcrawlers
5x Gold Bar
5x Iron Bar
60x Solid Stone
66x Mithril Bar
5x Mageweave Cloth
40x Dense Stone
40x Thorium Bar
14x Runecloth

|cff00ff00TBC|r

28x Fel Iron Bar
10x Mote of Fire
20x Mote of Earth
21x Elemental Blasting Powder
16x Adamantite Bar
20x Netherweave Cloth

|cff00ffffWotLK|r

68x Cobalt Bar
17x Crystallized Water
5x Frostweave Cloth
6x Volatile Blasting Trigger
117x Saronite Bar
18x Eternal Air
4x Twilight Opal
3x Skinning Knife
3x Mining Pick
3x Blacksmith Hammer
8x Titanium Bar
2x Eternal Shadow
2x Eternal Water
2x Eternal Fire
]])
        PLHEngineeringFrame.fontString2:SetText(text2)
        PLHEngineeringFrame.scrollFrame2:UpdateScrollChildRect()
        local h2 = PLHEngineeringFrame.fontString2:GetStringHeight()
        PLHEngineeringFrame.fontString2:GetParent():SetSize(200, h2 > 400 and h2 or 400)
    else
        PLHEngineeringFrame.fontString1:SetText("No guide found.")
        PLHEngineeringFrame.fontString2:SetText("No additional content found.")
    end

    PLHEngineeringFrame:Show()
end

-----------------------------------------------------------------------------------
