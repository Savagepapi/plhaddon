
ProfessionGuides = {
        
    ["Engineering"] = {
        
        -- Classic

        { level = 1,   recipe = "1-40 20x Rough Blasting Powder", color = "|cffffff00", mats = "20x Rough Stone" },
        { level = 40,  recipe = "40-55 5x Rough Dynamites",          color = "|cffffff00", mats = "10x Rough Blasting Powder, 5x Linen Cloth" },
        { level = 55,  recipe = "55-58 1x Arclight Spanner",         color = "|cffffff00", mats = "6x Copper Bar" },
        { level = 58,  recipe = "58-85 9-10x Copper Tube",           color = "|cffffff00", mats = "18-20x Copper Bar, 9-10x Weak Flux" },
        { level = 85,  recipe = "85-97 20x Coarse Blasting Powder",  color = "|cffffff00", mats = "20x Coarse Stone" },
        { level = 97,  recipe = "97-127 15x Silver Contact",         color = "|cffffff00", mats = "15x Silver Bar" },
        { level = 127, recipe = "127-145 20x Heavy Blasting Powder", color = "|cffffff00", mats = "20x Heavy Stone" },
        { level = 145, recipe = "145-151 2-4x Big Bronze Bomb",      color = "|cffffff00", mats = "4-8x Heavy Blasting Powder, 6-12x Bronze Bar, 2-4x Silver Contact" },
        { level = 151, recipe = "151-175 20x Gold Power Core",       color = "|cffffff00", mats = "20x Gold Bar" },
        { level = 175, recipe = "175-178 1x Gyromatic Micro-Adjustor", color = "|cffffff00", mats = "4x Steel Bar" },
        { level = 178, recipe = "178-196 40x Solid Blasting Powder", color = "|cffffff00", mats = "80x Solid Stone" },
        { level = 196, recipe = "196-202 2x Mithril Tubes",          color = "|cffffff00", mats = "6x Mithril Bar" },
        { level = 202, recipe = "202-220 8x Unstable Trigger",       color = "|cffffff00", mats = "8x Mithril Bar, 8x Mageweave Cloth, 8x Solid Blasting Powder" },
        { level = 220, recipe = "220-232 7x Hi-Impact Mithril Slugs", color = "|cffffff00", mats = "7x Mithril Bar, 7x Solid Blasting Powder" },
        { level = 232, recipe = "232-250 6-7x Spellpower Goggles Xtreme", color = "|cffffff00", mats = "24-28x Thick Leather, 12-14x Star Ruby" },
        { level = 250, recipe = "250-262 20x Dense Blasting Powder", color = "|cffffff00", mats = "40x Dense Stone" },
        { level = 262, recipe = "262-277 10x Mithril Gyro-Shot",    color = "|cffffff00", mats = "20x Mithril Bar, 20x Solid Blasting Powder" },
        { level = 277, recipe = "277-292 6x Thorium Widget",        color = "|cffffff00", mats = "18x Thorium Bar, 6x Runecloth" },
        { level = 292, recipe = "292-300 3x Thorium Shell",         color = "|cffffff00", mats = "6x Thorium Bar, 3x Dense Blasting Powder" },

        -- TBC

        { level = 300, recipe = "300-321 15-20x Elemental Blasting Powder", color = "|cff00ff00", mats = "15-20x Mote of Fire, 30-40x Mote of Earth" },
        { level = 321, recipe = "321-327 2x Fel Iron Bomb",            color = "|cff00ff00", mats = "2x Fel Iron Casing, 4x Handful of Fel Iron Bolts, 2x Elemental Blasting Powder" },
        { level = 327, recipe = "327-336 3x Adamantite Grenade",       color = "|cff00ff00", mats = "12x Adamantite Bar, 6x Handful of Fel Iron Bolts, 3x Elemental Blasting Powder" },
        { level = 336, recipe = "336-357 20x White Smoke Flare",       color = "|cff00ff00", mats = "20x Elemental Blasting Powder, 20x Netherweave Cloth" },

        -- WotLK

        { level = 357, recipe = "357-378 10x Handful of Cobalt Bolts",       color = "|cff00ffff", mats = "20x Cobalt Bar" },
        { level = 378, recipe = "378-387 3x Hammer Pick",                    color = "|cff00ffff", mats = "15x Cobalt Bar" },
        { level = 387, recipe = "387-393 4x Explosive Decoy",                color = "|cff00ffff", mats = "4x Frostweave Cloth, 12x Volatile Blasting Trigger" },
        { level = 393, recipe = "393-402 3x Froststeel Tube",                color = "|cff00ffff", mats = "24x Cobalt Bar, 3x Crystallized Water" },
        { level = 402, recipe = "402-408 3x Diamond-cut Refractor Scope",    color = "|cff00ffff", mats = "3x Froststeel Tube, 6x Handful of Cobalt Bolts" },
        { level = 408, recipe = "408-411 2x Box of Bombs",                   color = "|cff00ffff", mats = "10x Saronite Bar, 2x Volatile Blasting Trigger" },
        { level = 411, recipe = "411-417 5x Mammoth Cutters",                color = "|cff00ffff", mats = "5x Saronite Bar, 5x Volatile Blasting Trigger" },
        { level = 417, recipe = "417-426 3x Mana Injector Kit",              color = "|cff00ffff", mats = "36x Saronite Bar, 6x Crystallized Water" },
        { level = 426, recipe = "426-432 2x MOLL-E",                         color = "|cff00ffff", mats = "16x Saronite Bar, 16x Eternal Air" },
        { level = 432, recipe = "432-438 2x Heartseeker Scope",              color = "|cff00ffff", mats = "20x Saronite Bar, 4x Twilight Opal" },
        { level = 438, recipe = "438-447 3x Gnomish Army Knife",             color = "|cff00ffff", mats = "30x Saronite Bar, 3x Skinning Knife, 3x Mining Pick, 3x Blacksmith Hammer" },
        { level = 447, recipe = "447-450 1x Wormhole Generator: Northrend", color = "|cff00ffff", mats = "8x Titanium Bar, 2x Eternal Shadow, 2x Eternal Water, 2x Eternal Fire, 2x Eternal Air" },

    },    
}

-----------------------------------------------------------------------------
SLASH_PLHENGINEERING1 = "/plheng"
SlashCmdList["PLHENGINEERING"] = function()
    -- Ha már meg van nyitva, zárja be
    if PLHEngineeringFrame and PLHEngineeringFrame:IsShown() then
        PLHEngineeringFrame:Hide()
        return
    end

    -- Ha még nincs létrehozva, hozzuk létre
    if not PLHEngineeringFrame then
        local frame = CreateFrame("Frame", "PLHEngineeringFrame", UIParent, "BackdropTemplate")
        frame:SetSize(575, 445)
        frame:SetPoint("CENTER")
        frame:SetBackdrop({
            bgFile = "Interface/DialogFrame/UI-DialogBox-Background",
            edgeFile = "Interface/DialogFrame/UI-DialogBox-Border",
            tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 8, right = 8, top = 8, bottom = 8 }
        })
        frame:SetMovable(true)
        frame:EnableMouse(true)
        frame:RegisterForDrag("LeftButton")
        frame:SetScript("OnDragStart", frame.StartMoving)
        frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
        frame:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
            end
        end)

        -- Fejléc
        local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        title:SetPoint("TOP", 0, -10)
        title:SetText("Engineering Guide")
        title:SetFont("Fonts\\FRIZQT__.TTF", 16)

        -- Bezáró gomb
        local closeButton = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
        closeButton:SetPoint("TOPRIGHT", -5, -5)
        closeButton:SetScript("OnClick", function()
            frame:Hide()
        end)

        -- Frissítés gomb
        local refreshButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
        refreshButton:SetSize(60, 20)
        refreshButton:SetPoint("RIGHT", closeButton, "LEFT", -4, 0)
        refreshButton:SetText("Refresh")
        refreshButton:SetScript("OnClick", function()
            if PLHEngineeringFrame then
                local frame = PLHEngineeringFrame

                -- Első scroll frame frissítése
                local guideLines = ProfessionGuides and ProfessionGuides["Engineering"]
                if guideLines and #guideLines > 0 then
                    local text1 = ""
                    for _, guide in ipairs(guideLines) do
                        text1 = text1 .. guide.color .. guide.recipe .. "\n" .. guide.mats .. "|r\n\n"
                    end
                    frame.fontString1:SetText(text1)
                    frame.scrollFrame1:UpdateScrollChildRect()
                    local h1 = frame.fontString1:GetStringHeight()
                    frame.fontString1:GetParent():SetSize(300, h1 > 400 and h1 or 400)
                end

                -- Második scroll frame frissítése valós tartalommal
                local text2 = AddItemCountsToText([[|cffFFFF00Classic|r

20x Rough Stone
10x Linen Cloth
26x Copper Bar
10x Weak Flux
20x Coarse Stone
15x Silver Bar
20x Heavy Stone
12x Bronze Bar
20x Gold Bar
4x Steel Bar
80x Solid Stone
41x Mithril Bar
8x Mageweave Cloth
28x Thick Leather
14x Star ruby
40x Dense Stone
24x Thorium Bar
6x Runecloth

|cff00ff00TBC|r
35x Mote of Fire
70x Mote of Earth
2x Fel Iron Casing
10x Handful of Fel Iron Bolts
12x Adamantite Bar
20x Green dye

|cff00ffffWotLK|r
59x Cobalt bar
4x Frostweave Cloth
19x Volatile Blasting Trigger
9x Crystallized Water
117x Saronite Bar
18x Eternal Air
2x Eternal Shadow
2x Eternal Fire
2x Eternal Water
4x Twilight Opal
8x Titanium bar
3x Mining Pick
3x Skinning Knife
3x Blacksmith Hammer
]])

                frame.fontString2:SetText(text2)
                frame.scrollFrame2:UpdateScrollChildRect()
                local h2 = frame.fontString2:GetStringHeight()
                frame.fontString2:GetParent():SetSize(200, h2 > 400 and h2 or 400)
            end
        end)

        -- Első scroll frame
        local scrollFrame1 = CreateFrame("ScrollFrame", "PLHScrollFrame1", frame, "UIPanelScrollFrameTemplate")
        scrollFrame1:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -32)
        scrollFrame1:SetSize(300, 400)
        frame.scrollFrame1 = scrollFrame1

        local content1 = CreateFrame("Frame", nil, scrollFrame1)
        scrollFrame1:SetScrollChild(content1)

        local fontString1 = content1:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
        fontString1:SetPoint("TOPLEFT")
        fontString1:SetWidth(300)
        fontString1:SetWordWrap(true)
        fontString1:SetJustifyH("LEFT")
        fontString1:SetJustifyV("TOP")
        fontString1:SetText("Loading...")
        fontString1:SetFont("Fonts\\FRIZQT__.TTF", 14)

        local textHeight1 = fontString1:GetStringHeight()
        content1:SetSize(300, textHeight1 > 400 and textHeight1 or 400)

        -- Második scroll frame
        local scrollFrame2 = CreateFrame("ScrollFrame", "PLHScrollFrame2", frame, "UIPanelScrollFrameTemplate")
        scrollFrame2:SetPoint("TOPLEFT", scrollFrame1, "TOPRIGHT", 24, 0)
        scrollFrame2:SetSize(200, 400)
        frame.scrollFrame2 = scrollFrame2

        local content2 = CreateFrame("Frame", nil, scrollFrame2)
        scrollFrame2:SetScrollChild(content2)

        local fontString2 = content2:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
        fontString2:SetPoint("TOPLEFT")
        fontString2:SetWidth(200)
        fontString2:SetWordWrap(true)
        fontString2:SetJustifyH("LEFT")
        fontString2:SetJustifyV("TOP")
        fontString2:SetText("Additional content loading...")
        fontString2:SetFont("Fonts\\FRIZQT__.TTF", 14)

        local textHeight2 = fontString2:GetStringHeight()
        content2:SetSize(200, textHeight2 > 400 and textHeight2 or 400)

        frame.fontString1 = fontString1
        frame.fontString2 = fontString2
        PLHEngineeringFrame = frame
    end

    -- 🔍 Betöltjük a guide-t és a második scroll frame tartalmát
    local guideLines = ProfessionGuides and ProfessionGuides["Engineering"]
    if guideLines and #guideLines > 0 then
        local text1 = ""
        for _, guide in ipairs(guideLines) do
            text1 = text1 .. guide.color .. guide.recipe .. "\n" .. guide.mats .. "|r\n\n"
        end
        PLHEngineeringFrame.fontString1:SetText(text1)
        PLHEngineeringFrame.scrollFrame1:UpdateScrollChildRect()
        local h1 = PLHEngineeringFrame.fontString1:GetStringHeight()
        PLHEngineeringFrame.fontString1:GetParent():SetSize(300, h1 > 400 and h1 or 400)

        local text2 = AddItemCountsToText([[|cffFFFF00Classic|r

20x Rough Stone
10x Linen Cloth
26x Copper Bar
10x Weak Flux
20x Coarse Stone
15x Silver Bar
20x Heavy Stone
12x Bronze Bar
20x Gold Bar
4x Steel Bar
80x Solid Stone
41x Mithril Bar
8x Mageweave Cloth
28x Thick Leather
14x Star ruby
40x Dense Stone
24x Thorium Bar
6x Runecloth

|cff00ff00TBC|r
35x Mote of Fire
70x Mote of Earth
2x Fel Iron Casing
10x Handful of Fel Iron Bolts
12x Adamantite Bar
20x Green dye

|cff00ffffWotLK|r
59x Cobalt bar
4x Frostweave Cloth
19x Volatile Blasting Trigger
9x Crystallized Water
117x Saronite Bar
18x Eternal Air
2x Eternal Shadow
2x Eternal Fire
2x Eternal Water
4x Twilight Opal
8x Titanium bar
3x Mining Pick
3x Skinning Knife
3x Blacksmith Hammer
]])
        PLHEngineeringFrame.fontString2:SetText(text2)
        PLHEngineeringFrame.scrollFrame2:UpdateScrollChildRect()
        local h2 = PLHEngineeringFrame.fontString2:GetStringHeight()
        PLHEngineeringFrame.fontString2:GetParent():SetSize(200, h2 > 400 and h2 or 400)
    else
        PLHEngineeringFrame.fontString1:SetText("No guide found.")
        PLHEngineeringFrame.fontString2:SetText("No additional content found.")
    end

    PLHEngineeringFrame:Show()
end

-----------------------------------------------------------------------------------
